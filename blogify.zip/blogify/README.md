# Blogify – Django Dynamic Blog / News Website

```
python -m venv venv
venv\Scripts\activate          # Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations blog
python manage.py migrate
python manage.py seed          # demo posts (login: demo_author / demo12345)
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/  (admin: /admin/)

Features: posts stored in a database, search, category filter, pagination, popular posts,
view counter, comments (login required), signup/login/logout, write/edit/delete your own posts
(draft or published, with image upload), "My posts" dashboard, and a full admin panel.
