from .models import Category


def sidebar(request):
    return {"nav_categories": Category.objects.all()}
