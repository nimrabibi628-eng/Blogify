from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils.text import slugify

from blog.models import Category, Post

POSTS = [
    ("Technology", "Getting started with Django", "Django is a high-level Python web framework that helps you build secure sites quickly."),
    ("Technology", "Why static sites are still great", "Static sites are fast, cheap to host and easy to secure."),
    ("Technology", "Five tips for learning to code", "Build small projects, read other people's code and be patient with yourself."),
    ("Education", "How to prepare for semester exams", "Plan your revision, practise past papers and sleep well before the exam."),
    ("Education", "Making a good project report", "Explain the problem, your approach and the results with clear screenshots."),
    ("Lifestyle", "Staying focused while studying", "Remove distractions, work in short sessions and take real breaks."),
    ("Lifestyle", "Simple desk setup for students", "A tidy desk, good light and a comfortable chair improve your work."),
    ("News", "Open source keeps growing", "More students and companies now contribute to open source projects every year."),
]


class Command(BaseCommand):
    help = "Create a demo author, categories and sample posts"

    def handle(self, *args, **options):
        User = get_user_model()
        author, created = User.objects.get_or_create(username="demo_author")
        if created:
            author.set_password("demo12345")
            author.save()
        added = 0
        for cat_name, title, body in POSTS:
            cat, _ = Category.objects.get_or_create(name=cat_name, defaults={"slug": slugify(cat_name)})
            _, new = Post.objects.get_or_create(
                slug=slugify(title),
                defaults={"author": author, "category": cat, "title": title,
                          "excerpt": body, "body": (body + "\n\n") * 6, "status": "published"},
            )
            added += new
        self.stdout.write(self.style.SUCCESS(f"Added {added} posts (demo login: demo_author / demo12345)."))
