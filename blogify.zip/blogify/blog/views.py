from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import redirect_to_login
from django.core.paginator import Paginator
from django.db.models import F, Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CommentForm, PostForm, SignupForm
from .models import Post


def home(request):
    posts = Post.objects.filter(status="published").select_related("author", "category")
    q = request.GET.get("q", "").strip()
    category = request.GET.get("category", "")
    if q:
        posts = posts.filter(Q(title__icontains=q) | Q(body__icontains=q))
    if category:
        posts = posts.filter(category__slug=category)

    page = Paginator(posts, 6).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    popular = Post.objects.filter(status="published").order_by("-views")[:5]
    return render(request, "blog/home.html", {
        "page": page, "q": q, "active_category": category,
        "querystring": params.urlencode(), "popular": popular,
    })


def post_detail(request, slug):
    post = get_object_or_404(Post.objects.select_related("author", "category"), slug=slug)
    is_owner = request.user.is_authenticated and (post.author_id == request.user.id or request.user.is_staff)
    if post.status != "published" and not is_owner:
        raise Http404

    form = CommentForm(request.POST or None)
    if request.method == "POST":
        if not request.user.is_authenticated:
            return redirect_to_login(request.get_full_path())
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.user = request.user
            comment.save()
            messages.success(request, "Comment added.")
            return redirect(post)
    elif post.status == "published":
        Post.objects.filter(pk=post.pk).update(views=F("views") + 1)
        post.refresh_from_db(fields=["views"])

    related = Post.objects.filter(status="published", category=post.category).exclude(pk=post.pk)[:3] if post.category else []
    return render(request, "blog/post_detail.html", {
        "post": post, "form": form, "comments": post.comments.select_related("user"),
        "related": related, "is_owner": is_owner,
    })


@login_required
def post_create(request):
    form = PostForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        post = form.save(commit=False)
        post.author = request.user
        post.save()
        messages.success(request, "Post saved.")
        return redirect(post)
    return render(request, "blog/post_form.html", {"form": form, "heading": "Write a new post"})


@login_required
def post_update(request, slug):
    post = get_object_or_404(Post, slug=slug)
    if post.author != request.user and not request.user.is_staff:
        raise Http404
    form = PostForm(request.POST or None, request.FILES or None, instance=post)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Post updated.")
        return redirect(post)
    return render(request, "blog/post_form.html", {"form": form, "heading": "Edit post"})


@login_required
def post_delete(request, slug):
    post = get_object_or_404(Post, slug=slug)
    if post.author != request.user and not request.user.is_staff:
        raise Http404
    if request.method == "POST":
        post.delete()
        messages.info(request, "Post deleted.")
        return redirect("my_posts")
    return render(request, "blog/post_confirm_delete.html", {"post": post})


@login_required
def my_posts(request):
    posts = Post.objects.filter(author=request.user)
    return render(request, "blog/my_posts.html", {"posts": posts})


def signup(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = SignupForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Welcome! Your account has been created.")
        return redirect("home")
    return render(request, "registration/signup.html", {"form": form})
