// Ask before leaving a half-written post form
(function () {
  var form = document.querySelector("form[enctype='multipart/form-data']");
  if (!form) return;
  var dirty = false, saving = false;
  form.addEventListener("input", function () { dirty = true; });
  form.addEventListener("submit", function () { saving = true; });
  window.addEventListener("beforeunload", function (e) {
    if (dirty && !saving) { e.preventDefault(); e.returnValue = ""; }
  });
})();
